{pkgs}: {
  deps = [
    pkgs.zip
  ];
}
